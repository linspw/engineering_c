#include <stdio.h>

void main(void) {
  float celcius = 4;
  float fahrenheit;

  float total;

  float fracao;


  fahrenheit = ((float)9/5 * celcius) + 32;

  printf("fahrenheit: %.2f\n", fahrenheit);

  return;
}
